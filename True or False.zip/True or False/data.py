# 12 dictionaries inside a list
question_data = [
    {
        "category": "General Knowledge",
        "type": "boolean",
        "difficulty": "medium",
        "question": "The vapor produced by e-cigarettes is actually water.",
        "correct_answer": "False",
        "incorrect_answers": ["True"]},
    {
        "category": "General Knowledge",
        "type": "boolean",
        "difficulty": "medium",
        "question": "The word 'news' originates from the first letters of the 4 main directions "
                    "on a compass (North, East, West, South).",
        "correct_answer": "False",
        "incorrect_answers": ["True"]},
    {
        "category": "General Knowledge",
        "type": "boolean",
        "difficulty": "medium",
        "question": "Sitting for more than three hours a day can cut two years off a person&#039;s life expectancy.",
        "correct_answer": "True",
        "incorrect_answers": ["False"]},
    {
        "category": "General Knowledge",
        "type": "boolean",
        "difficulty": "medium",
        "question": "Albert Einstein had trouble with mathematics when he was in school.",
        "correct_answer": "False",
        "incorrect_answers": ["True"]},
    {"category": "General Knowledge", "type": "boolean", "difficulty": "medium",
     "question": "Fast food restaurant chains Carl's Jr. and Hardee's are owned by the same company.",
     "correct_answer": "True", "incorrect_answers": ["False"]},
    {"category": "General Knowledge", "type": "boolean", "difficulty": "medium",
     "question": "Haggis is traditionally ate on Burns Night.", "correct_answer": "True",
     "incorrect_answers": ["False"]},
    {
        "category": "General Knowledge",
        "type": "boolean",
        "difficulty": "medium",
        "question": "Francis Bacon died from a fatal case of pneumonia while he was attempting to preserve "
                    "meat by stuffing a chicken with snow.",
        "correct_answer": "True",
        "incorrect_answers": ["False"]},
    {"category": "General Knowledge", "type": "boolean", "difficulty": "medium",
     "question": "The commercial UK channel ITV stands for 'International Television'.",
     "correct_answer": "False", "incorrect_answers": ["True"]},
    {"category": "General Knowledge", "type": "boolean", "difficulty": "medium",
     "question": "The pickled gherkin was first added to hamburgers because a US health"
                 " law required all fast-food to include a source of Vitamin C.",
     "correct_answer": "False", "incorrect_answers": ["True"]},
    {"category": "General Knowledge", "type": "boolean", "difficulty": "medium",
     "question": "'Buffalo buffalo Buffalo buffalo buffalo buffalo Buffalo "
                 "buffalo.' is a grammatically correct sentence.",
     "correct_answer": "True", "incorrect_answers": ["False"]}
]
